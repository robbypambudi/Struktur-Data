#include "header.h"

// Primary Function untuk membuat node baru
void bst_init(BST *bst)
{
    bst->_root = NULL; // Inisialisasi root
    bst->_size = 0;    // Inisialisasi size
}