
// Fungsi untuk mengecek apakah fungsi tersebut kosong atau tidak
#include "header.h"

bool bst_empty(BST *bst)
{
    return bst->_root == NULL;
}