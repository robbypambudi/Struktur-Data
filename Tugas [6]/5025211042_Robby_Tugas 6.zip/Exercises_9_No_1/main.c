/
#include "header.h"

    int main()
{
    puts("Soal 1 -Inisialisasi BST");
    BST set;        // Deklarasi variabel set
    bst_init(&set); // Inisialisasi variabel set
}