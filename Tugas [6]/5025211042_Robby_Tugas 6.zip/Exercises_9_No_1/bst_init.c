#include "header.h" // Deklarasi variabel set

// Fungsi untuk inisiasi BST
void bst_init(BST *bst)
{
    bst->_root = NULL; // Inisialisasi variabel set
    bst->_size = 0;    // Inisialisasi variabel set
}
