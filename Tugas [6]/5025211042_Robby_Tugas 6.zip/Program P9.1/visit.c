#include "header.h"

void visit(TreeNodePtr node)
{
    printf("%s ", node->data.word);
} // end visit