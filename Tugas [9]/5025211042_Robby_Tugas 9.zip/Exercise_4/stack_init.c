

#include "header.h"
void stack_init(Stack *stack)
{
	stack->_size = 0;
	stack->_top = NULL;
}
