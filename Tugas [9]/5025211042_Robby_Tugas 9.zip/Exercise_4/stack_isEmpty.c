
#include "header.h"

bool stack_isEmpty(Stack *stack)
{
	return (stack->_top == NULL);
}
